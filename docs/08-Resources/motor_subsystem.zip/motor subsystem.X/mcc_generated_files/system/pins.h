/**
 * Generated Pins header File
 * 
 * @file pins.h
 * 
 * @defgroup  pinsdriver Pins Driver
 * 
 * @brief This is generated driver header for pins. 
 *        This header file provides APIs for all pins selected in the GUI.
 *
 * @version Driver Version  3.1.1
*/

/*
� [2025] Microchip Technology Inc. and its subsidiaries.

    Subject to your compliance with these terms, you may use Microchip 
    software and any derivatives exclusively with Microchip products. 
    You are responsible for complying with 3rd party license terms  
    applicable to your use of 3rd party software (including open source  
    software) that may accompany Microchip software. SOFTWARE IS ?AS IS.? 
    NO WARRANTIES, WHETHER EXPRESS, IMPLIED OR STATUTORY, APPLY TO THIS 
    SOFTWARE, INCLUDING ANY IMPLIED WARRANTIES OF NON-INFRINGEMENT,  
    MERCHANTABILITY, OR FITNESS FOR A PARTICULAR PURPOSE. IN NO EVENT 
    WILL MICROCHIP BE LIABLE FOR ANY INDIRECT, SPECIAL, PUNITIVE, 
    INCIDENTAL OR CONSEQUENTIAL LOSS, DAMAGE, COST OR EXPENSE OF ANY 
    KIND WHATSOEVER RELATED TO THE SOFTWARE, HOWEVER CAUSED, EVEN IF 
    MICROCHIP HAS BEEN ADVISED OF THE POSSIBILITY OR THE DAMAGES ARE 
    FORESEEABLE. TO THE FULLEST EXTENT ALLOWED BY LAW, MICROCHIP?S 
    TOTAL LIABILITY ON ALL CLAIMS RELATED TO THE SOFTWARE WILL NOT 
    EXCEED AMOUNT OF FEES, IF ANY, YOU PAID DIRECTLY TO MICROCHIP FOR 
    THIS SOFTWARE.
*/

#ifndef PINS_H
#define PINS_H

#include <xc.h>

#define INPUT   1
#define OUTPUT  0

#define HIGH    1
#define LOW     0

#define ANALOG      1
#define DIGITAL     0

#define PULL_UP_ENABLED      1
#define PULL_UP_DISABLED     0

// get/set RC7 aliases
#define DEBUG_LED_TRIS                 TRISCbits.TRISC7
#define DEBUG_LED_LAT                  LATCbits.LATC7
#define DEBUG_LED_PORT                 PORTCbits.RC7
#define DEBUG_LED_WPU                  WPUCbits.WPUC7
#define DEBUG_LED_OD                   ODCONCbits.ODCC7
#define DEBUG_LED_ANS                  ANSELCbits.ANSELC7
#define DEBUG_LED_SetHigh()            do { LATCbits.LATC7 = 1; } while(0)
#define DEBUG_LED_SetLow()             do { LATCbits.LATC7 = 0; } while(0)
#define DEBUG_LED_Toggle()             do { LATCbits.LATC7 = ~LATCbits.LATC7; } while(0)
#define DEBUG_LED_GetValue()           PORTCbits.RC7
#define DEBUG_LED_SetDigitalInput()    do { TRISCbits.TRISC7 = 1; } while(0)
#define DEBUG_LED_SetDigitalOutput()   do { TRISCbits.TRISC7 = 0; } while(0)
#define DEBUG_LED_SetPullup()          do { WPUCbits.WPUC7 = 1; } while(0)
#define DEBUG_LED_ResetPullup()        do { WPUCbits.WPUC7 = 0; } while(0)
#define DEBUG_LED_SetPushPull()        do { ODCONCbits.ODCC7 = 0; } while(0)
#define DEBUG_LED_SetOpenDrain()       do { ODCONCbits.ODCC7 = 1; } while(0)
#define DEBUG_LED_SetAnalogMode()      do { ANSELCbits.ANSELC7 = 1; } while(0)
#define DEBUG_LED_SetDigitalMode()     do { ANSELCbits.ANSELC7 = 0; } while(0)

// get/set RD2 aliases
#define REV_TRIS                 TRISDbits.TRISD2
#define REV_LAT                  LATDbits.LATD2
#define REV_PORT                 PORTDbits.RD2
#define REV_WPU                  WPUDbits.WPUD2
#define REV_OD                   ODCONDbits.ODCD2
#define REV_ANS                  ANSELDbits.ANSELD2
#define REV_SetHigh()            do { LATDbits.LATD2 = 1; } while(0)
#define REV_SetLow()             do { LATDbits.LATD2 = 0; } while(0)
#define REV_Toggle()             do { LATDbits.LATD2 = ~LATDbits.LATD2; } while(0)
#define REV_GetValue()           PORTDbits.RD2
#define REV_SetDigitalInput()    do { TRISDbits.TRISD2 = 1; } while(0)
#define REV_SetDigitalOutput()   do { TRISDbits.TRISD2 = 0; } while(0)
#define REV_SetPullup()          do { WPUDbits.WPUD2 = 1; } while(0)
#define REV_ResetPullup()        do { WPUDbits.WPUD2 = 0; } while(0)
#define REV_SetPushPull()        do { ODCONDbits.ODCD2 = 0; } while(0)
#define REV_SetOpenDrain()       do { ODCONDbits.ODCD2 = 1; } while(0)
#define REV_SetAnalogMode()      do { ANSELDbits.ANSELD2 = 1; } while(0)
#define REV_SetDigitalMode()     do { ANSELDbits.ANSELD2 = 0; } while(0)

// get/set RD3 aliases
#define FWD_TRIS                 TRISDbits.TRISD3
#define FWD_LAT                  LATDbits.LATD3
#define FWD_PORT                 PORTDbits.RD3
#define FWD_WPU                  WPUDbits.WPUD3
#define FWD_OD                   ODCONDbits.ODCD3
#define FWD_ANS                  ANSELDbits.ANSELD3
#define FWD_SetHigh()            do { LATDbits.LATD3 = 1; } while(0)
#define FWD_SetLow()             do { LATDbits.LATD3 = 0; } while(0)
#define FWD_Toggle()             do { LATDbits.LATD3 = ~LATDbits.LATD3; } while(0)
#define FWD_GetValue()           PORTDbits.RD3
#define FWD_SetDigitalInput()    do { TRISDbits.TRISD3 = 1; } while(0)
#define FWD_SetDigitalOutput()   do { TRISDbits.TRISD3 = 0; } while(0)
#define FWD_SetPullup()          do { WPUDbits.WPUD3 = 1; } while(0)
#define FWD_ResetPullup()        do { WPUDbits.WPUD3 = 0; } while(0)
#define FWD_SetPushPull()        do { ODCONDbits.ODCD3 = 0; } while(0)
#define FWD_SetOpenDrain()       do { ODCONDbits.ODCD3 = 1; } while(0)
#define FWD_SetAnalogMode()      do { ANSELDbits.ANSELD3 = 1; } while(0)
#define FWD_SetDigitalMode()     do { ANSELDbits.ANSELD3 = 0; } while(0)

// get/set RF4 aliases
#define DEBUG_BTN_TRIS                 TRISFbits.TRISF4
#define DEBUG_BTN_LAT                  LATFbits.LATF4
#define DEBUG_BTN_PORT                 PORTFbits.RF4
#define DEBUG_BTN_WPU                  WPUFbits.WPUF4
#define DEBUG_BTN_OD                   ODCONFbits.ODCF4
#define DEBUG_BTN_ANS                  ANSELFbits.ANSELF4
#define DEBUG_BTN_SetHigh()            do { LATFbits.LATF4 = 1; } while(0)
#define DEBUG_BTN_SetLow()             do { LATFbits.LATF4 = 0; } while(0)
#define DEBUG_BTN_Toggle()             do { LATFbits.LATF4 = ~LATFbits.LATF4; } while(0)
#define DEBUG_BTN_GetValue()           PORTFbits.RF4
#define DEBUG_BTN_SetDigitalInput()    do { TRISFbits.TRISF4 = 1; } while(0)
#define DEBUG_BTN_SetDigitalOutput()   do { TRISFbits.TRISF4 = 0; } while(0)
#define DEBUG_BTN_SetPullup()          do { WPUFbits.WPUF4 = 1; } while(0)
#define DEBUG_BTN_ResetPullup()        do { WPUFbits.WPUF4 = 0; } while(0)
#define DEBUG_BTN_SetPushPull()        do { ODCONFbits.ODCF4 = 0; } while(0)
#define DEBUG_BTN_SetOpenDrain()       do { ODCONFbits.ODCF4 = 1; } while(0)
#define DEBUG_BTN_SetAnalogMode()      do { ANSELFbits.ANSELF4 = 1; } while(0)
#define DEBUG_BTN_SetDigitalMode()     do { ANSELFbits.ANSELF4 = 0; } while(0)

// get/set RF5 aliases
#define DIGIN_TRIS                 TRISFbits.TRISF5
#define DIGIN_LAT                  LATFbits.LATF5
#define DIGIN_PORT                 PORTFbits.RF5
#define DIGIN_WPU                  WPUFbits.WPUF5
#define DIGIN_OD                   ODCONFbits.ODCF5
#define DIGIN_ANS                  ANSELFbits.ANSELF5
#define DIGIN_SetHigh()            do { LATFbits.LATF5 = 1; } while(0)
#define DIGIN_SetLow()             do { LATFbits.LATF5 = 0; } while(0)
#define DIGIN_Toggle()             do { LATFbits.LATF5 = ~LATFbits.LATF5; } while(0)
#define DIGIN_GetValue()           PORTFbits.RF5
#define DIGIN_SetDigitalInput()    do { TRISFbits.TRISF5 = 1; } while(0)
#define DIGIN_SetDigitalOutput()   do { TRISFbits.TRISF5 = 0; } while(0)
#define DIGIN_SetPullup()          do { WPUFbits.WPUF5 = 1; } while(0)
#define DIGIN_ResetPullup()        do { WPUFbits.WPUF5 = 0; } while(0)
#define DIGIN_SetPushPull()        do { ODCONFbits.ODCF5 = 0; } while(0)
#define DIGIN_SetOpenDrain()       do { ODCONFbits.ODCF5 = 1; } while(0)
#define DIGIN_SetAnalogMode()      do { ANSELFbits.ANSELF5 = 1; } while(0)
#define DIGIN_SetDigitalMode()     do { ANSELFbits.ANSELF5 = 0; } while(0)

/**
 * @ingroup  pinsdriver
 * @brief GPIO and peripheral I/O initialization
 * @param none
 * @return none
 */
void PIN_MANAGER_Initialize (void);

/**
 * @ingroup  pinsdriver
 * @brief Interrupt on Change Handling routine
 * @param none
 * @return none
 */
void PIN_MANAGER_IOC(void);


#endif // PINS_H
/**
 End of File
*/